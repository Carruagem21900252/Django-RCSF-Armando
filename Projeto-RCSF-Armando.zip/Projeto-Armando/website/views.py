from django.shortcuts import render
from .forms import FormEspacoLivre
from .functions import atenuacaoEspacoLivre, grafico_interferencia

from math import log10

def index(request):
    return render(request, "website/index.html")


def about(request):
    return render(request, "website/about.html")

def heatmap(request):
    return render(request, "website/heatmap.html")

def interferencia(request):
    grafico_interferencia()
    return render(request, "website/interferencia.html")

def diagramas(request):
    return render(request, "website/diagramas.html")


def espaco_livre(request):

    submetido = False
    form = FormEspacoLivre(request.POST or None)

    if form.is_valid():
        submetido = True
        atenuacaoEspacoLivre(
            form.cleaned_data['frequencia'],
            form.cleaned_data['potencia'],
            form.cleaned_data['prx_minima']
        )

    context = {'form': form, 'submetido': submetido}

    return render(request, "website/espaco-livre.html", context)

def trafego(request):
    return render(request, "website/trafego.html")

def tetra(request):
    return render(request, "website/tetra.html")

def cincog(request):
    return render(request, "website/cincog.html")

def nfc(request):
    return render(request, "website/nfc.html")


def planeamento_celular(request):
    return render(request, "website/planeamento_celular.html")


def potencia_recebida(request):

    try:


        ganho_emissor = float(request.POST['ge'])
        potencia_emitida = float(request.POST['pe'])
        ganho_recetor = float(request.POST['gr'])
        frequencia = float(request.POST['f'])
        distancia = float(request.POST['d'])

        atenuacao_0 = round(32.44 + 20*log10(distancia) + 20*log10(frequencia),2)
        potencia_recebida = round(potencia_emitida + ganho_emissor + ganho_recetor - atenuacao_0,2)

        return render(request,"website/potencia_recebida.html",
            {
                "potencia_emitida": potencia_emitida,
                "ganho_emissor": ganho_emissor,
                "ganho_recetor": ganho_recetor,
                "frequencia": frequencia,
                "distancia": distancia,
                "atenuacao_0": atenuacao_0,
                "potencia_recebida": potencia_recebida
            })

    except ValueError:
        return render(request,"website/heatmap.html")






    return render(request, "website/potencia_recebida.html", )



    
