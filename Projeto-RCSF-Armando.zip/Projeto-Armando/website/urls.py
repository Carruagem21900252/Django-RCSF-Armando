from django.urls import path
from .import views

app_name = "website"

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('tetra/', views.tetra, name='tetra'),
    path('cincog/', views.cincog, name='cincog'),
    path('nfc/', views.nfc, name='nfc'),
    path('espaco_livre', views.espaco_livre, name="espaco_livre"),
    path('interferencia', views.interferencia, name="interferencia"),
    path('diagramas', views.diagramas, name="diagramas"),
    path('heatmap', views.heatmap, name='heatmap'),
    path('trafego', views.trafego, name='trafego'),
    path('planeamento_celular', views.planeamento_celular, name='planeamento_celular'),
    path('potencia_recebida', views.potencia_recebida, name='potencia_recebida'),



]
